"""Frozen CPU controls for Newton's public smooth extrema; no GPU assertions."""

import math

import numpy as np
import warp as wp

import newton


@wp.kernel
def evaluate(
    a: wp.array(dtype=wp.float32),
    b: wp.array(dtype=wp.float32),
    eps: wp.array(dtype=wp.float32),
    smooth_hi: wp.array(dtype=wp.float32),
    smooth_lo: wp.array(dtype=wp.float32),
    leaky_hi: wp.array(dtype=wp.float32),
    leaky_lo: wp.array(dtype=wp.float32),
):
    i = wp.tid()
    smooth_hi[i] = newton.math.smooth_max(a[i], b[i], eps[i])
    smooth_lo[i] = newton.math.smooth_min(a[i], b[i], eps[i])
    leaky_hi[i] = newton.math.leaky_max(a[i], b[i])
    leaky_lo[i] = newton.math.leaky_min(a[i], b[i])


@wp.kernel
def evaluate_smooth_max(
    a: wp.array(dtype=wp.float32),
    b: wp.array(dtype=wp.float32),
    eps: wp.array(dtype=wp.float32),
    out: wp.array(dtype=wp.float32),
):
    out[0] = newton.math.smooth_max(a[0], b[0], eps[0])


@wp.kernel
def evaluate_smooth_min(
    a: wp.array(dtype=wp.float32),
    b: wp.array(dtype=wp.float32),
    eps: wp.array(dtype=wp.float32),
    out: wp.array(dtype=wp.float32),
):
    out[0] = newton.math.smooth_min(a[0], b[0], eps[0])


def oracle(a: float, b: float, eps: float) -> tuple[float, float]:
    half_sum = 0.5 * a + 0.5 * b
    radius = math.hypot(0.5 * a - 0.5 * b, 0.5 * math.sqrt(eps))
    return half_sum + radius, half_sum - radius


def oracle_gradient(a: float, b: float, eps: float, sign: int) -> tuple[float, float, float]:
    d = a - b
    radius = math.hypot(d, math.sqrt(eps))
    return 0.5 * (1.0 + sign * d / radius), 0.5 * (1.0 - sign * d / radius), sign / (4.0 * radius)


def warp_gradient(a: float, b: float, eps: float, kernel: object) -> tuple[float, float, float]:
    a_wp = wp.array([a], dtype=wp.float32, device="cpu", requires_grad=True)
    b_wp = wp.array([b], dtype=wp.float32, device="cpu", requires_grad=True)
    eps_wp = wp.array([eps], dtype=wp.float32, device="cpu", requires_grad=True)
    out = wp.empty(1, dtype=wp.float32, device="cpu", requires_grad=True)
    with wp.Tape() as tape:
        wp.launch(kernel, dim=1, inputs=[a_wp, b_wp, eps_wp, out], device="cpu")
    tape.backward(grads={out: wp.ones_like(out)})
    return float(a_wp.grad.numpy()[0]), float(b_wp.grad.numpy()[0]), float(eps_wp.grad.numpy()[0])


def main():
    smallest = float(np.nextafter(np.float32(0.0), np.float32(1.0)))
    cases = [
        ("ordinary", 2.0, 1.0, 1.0e-5),
        ("wide", 1.0e20, 0.0, 1.0e-5),
        ("wide_swapped", 0.0, 1.0e20, 1.0e-5),
        ("equal_large", 2.0e38, 2.0e38, 1.0e-5),
        ("opposite_large", 2.0e38, -2.0e38, 1.0e-5),
        ("opposite_swapped", -2.0e38, 2.0e38, 1.0e-5),
        ("tiny_eps_equal", 0.0, 0.0, smallest),
        ("tiny_eps_separated", 1.0e-22, 0.0, smallest),
        ("subnormal_inputs", smallest, -smallest, 1.0e-5),
    ]
    a = np.array([c[1] for c in cases], dtype=np.float32)
    b = np.array([c[2] for c in cases], dtype=np.float32)
    eps = np.array([c[3] for c in cases], dtype=np.float32)
    outputs = [wp.empty(len(cases), dtype=wp.float32, device="cpu") for _ in range(4)]
    wp.launch(
        evaluate,
        dim=len(cases),
        inputs=[
            wp.array(a, dtype=wp.float32, device="cpu"),
            wp.array(b, dtype=wp.float32, device="cpu"),
            wp.array(eps, dtype=wp.float32, device="cpu"),
            *outputs,
        ],
        device="cpu",
    )
    values = np.stack([x.numpy() for x in outputs])
    expected = np.array(
        [
            (*oracle(float(x), float(y), float(e)), *oracle(float(x), float(y), float(np.float32(1.0e-5))))
            for x, y, e in zip(a, b, eps, strict=True)
        ],
        dtype=np.float32,
    ).T
    for i, case in enumerate(cases):
        print(f"value {case[0]} inputs={(a[i], b[i], eps[i])} got={values[:, i].tolist()} oracle={expected[:, i].tolist()}", flush=True)

    gradient_cases = [
        ("equal", 0.0, 0.0, 1.0e-5),
        ("crossover", float(np.float32(math.sqrt(1.0e-5))), 0.0, 1.0e-5),
        ("far", 0.5, 0.0, 1.0e-5),
        ("wide", 1.0e20, 0.0, 1.0e-5),
        ("wide_swapped", 0.0, 1.0e20, 1.0e-5),
        ("tiny_eps_equal", 0.0, 0.0, smallest),
    ]
    gradient_results = []
    for label, x, y, e in gradient_cases:
        x, y, e = float(np.float32(x)), float(np.float32(y)), float(np.float32(e))
        for name, sign, kernel in (("max", 1, evaluate_smooth_max), ("min", -1, evaluate_smooth_min)):
            got = warp_gradient(x, y, e, kernel)
            ref = oracle_gradient(x, y, e, sign)
            gradient_results.append((label, name, got, ref))
            print(f"gradient {label} {name} got={got} oracle={ref}", flush=True)

    # Assert only representable outputs, not exact tiny correction after
    # cancellation at widely separated arguments.
    assert np.isfinite(values).all(), "finite-domain output became non-finite"
    np.testing.assert_allclose(values, expected, rtol=2.0e-5, atol=1.0e-4)
    for i in (6, 7):
        np.testing.assert_allclose(values[:2, i], expected[:2, i], rtol=2.0e-5, atol=1.0e-30)
    for label, name, got, ref in gradient_results:
        np.testing.assert_allclose(got, ref, rtol=5.0e-3, atol=1.0e-6, err_msg=f"{label} {name} gradient")


if __name__ == "__main__":
    main()
