# Frozen CPU cost measurement plan (no timing performed yet)

Compare official Newton baseline `a6e1649` against the isolated candidate source hash
`005c714a257915a32b01cc10358976bfb5926f6ca25d7d745a6e3edfff9fa88c`.
Use the pinned official Warp 1.18.0 runtime, CPU device, same host, Python/NumPy,
cache settings, affinity, and inputs. Run only after the competing Driver native
build reaches a terminal state and root gives a quiet window. GPU is NOT_RUN.

Two public-function Warp kernels, both operating on 131,072 deterministic
Float32 items, bounded to well below 100 MiB of input/output storage:

1. Dynamic-epsilon scalar: read `a[i]`, `b[i]`, and `eps[i]` from arrays, write
   `newton.math.smooth_max(a[i], b[i], eps[i])` and `smooth_min(...)`. Use a
   fixed random seed and ordinary finite values in [-2, 2], with mixed signs,
   exact ties, and positive eps drawn from {1e-5, 1e-3, 1e-1}. Inputs are
   identically generated in each run; eps is never a compile-time constant.
2. Fixed-epsilon XPBD caller pattern: read `dx[i]` as a vec3 and lower/upper
   Float32 scalars, form `lower_pos_limits = axis * lower[i]` and
   `upper_pos_limits = axis * upper[i]` with `axis=(1,0,0)`, then initialize
   `corr = wp.vec3(0.0)` and `zero = wp.vec3(0.0)`. Preserve the actual
   prismatic-correction statements and order from
   `newton/_src/solvers/xpbd/kernels.py`:
   `corr -= vec_leaky_min(zero, upper_pos_limits - dx[i]);` then
   `corr -= vec_leaky_max(zero, lower_pos_limits - dx[i]);`. Generate
   ordinary finite dx and lower/upper values with the same seed, including
   violations and in-limit positions; these wrappers use the in-tree fixed
   eps=1e-5. This isolates helper arithmetic, not whole-solver speed.

For each source, start a fresh process with its worktree on PYTHONPATH. Verify
source and test hashes before measurement, initialize Warp, compile/cache, and
perform 10 unmeasured launches per kernel. Then collect 21 synchronous
wall-clock CPU launch samples per kernel with identical arrays and outputs.
Take `time.perf_counter_ns()` immediately before `wp.launch`, call
`wp.synchronize_device("cpu")` immediately afterward, then take the second
counter reading. Synchronization cost is included equally on both sides.
Exclude process startup, compilation, warmup, allocation, and input generation.
Run baseline/candidate in ABBA order, repeat the four-run cycle three times
(12 processes total). Pre-allocate and reuse the same shape and dtype per run;
do not use asynchronous GPU timing. Save every raw sample, process order,
device/runtime metadata, source hashes, output checksums, and warmup details.
For ordinary finite inputs, check both source outputs against Float64 analytic
smooth max/min, including eps=0.1, and the XPBD correction formed from the
same analytic formulas. Require all results finite and Float32-close to the
oracle with rtol=2e-5 and atol=1e-6; do not require baseline and candidate
checksums to match, since differing rounding can be legitimate. Report
per-kernel per-cycle paired candidate/baseline ratios (geometric means of two
process medians each), pooled medians and p10/p90 across the six process
medians per source, plus every raw timing. These are descriptive samples,
not a CI bound or a significance claim. Do not infer a whole-solver speed
change from these kernels.
If load or temperature visibly shifts between blocks, mark the measurement
inconclusive rather than silently discarding samples. No performance claim
until root reviews the measurements and the extra divides/sqrt cost.
