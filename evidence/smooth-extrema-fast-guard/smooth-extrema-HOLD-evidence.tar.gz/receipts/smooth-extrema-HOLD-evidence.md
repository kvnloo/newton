# Newton smooth-extrema experiment — HOLD (2026-10-10 UTC)

This is a downstream, CPU-only numerical-correctness experiment. It is **not
merge-ready**. The final guarded implementation passes the frozen correctness
checks but has measurable CPU helper overhead; upstream promotion needs owner
acceptance and GPU / whole-solver cost review. No upstream post or push has
been made as part of this receipt.

## Provenance and scope

- Official public source: `newton-physics/newton` commit
  `a6e1649b112e3d962b35f7dad66780dc55150588` (2026-10-09).
- Current `smooth_max` / `smooth_min` implementation lineage credits Eric Heiden
  (introduction, `958e363c` / #1481) and Eric Shi (docstrings, #2308).
  The separate cached-mesh-inertia report #4319 belongs to its reporter,
  dvasquezlopez / Specula, and has overlapping PR #4324 by Mohit-Ak; it is
  outside this work. No overlapping open smooth-extrema implementation PR was
  found during the bounded ownership search.
- `newton.math.smooth_max/min(a,b,eps)` document a small **positive** smoothing
  parameter. `leaky_max/min` and `vec_leaky_max/min` use fixed `eps=1e-5`.
  XPBD calls the vector leaky functions in the prismatic joint correction
  (`newton/_src/solvers/xpbd/kernels.py:1519-1520`).
- The baseline formula computes `0.5*(a+b ± sqrt((a-b)^2+eps))`. With finite
  Float32 arguments and positive eps it can overflow an intermediate although
  the smooth result is finite: `(a,b,eps)=(1e20,0,1e-5)` yields `+Inf/-Inf`;
  `(2e38,2e38,1e-5)` yields `+Inf`; swapped and opposite-large cases were
  also reproduced. Baseline RED receipt: `red-baseline.log`, SHA256
  `fbdb30ec5fbf2325398450cb8bd30f553685cc272484aa36c6be4ef8e3ef70b8`.

## Frozen code and correctness

- Immutable baseline math SHA256
  `3d2196cfda9268410044efc24515c2f5b6a9bf661281c67f9c4941967a1f7531`.
- Candidate2, full scaled / rationalized correction: math SHA256
  `005c714a257915a32b01cc10358976bfb5926f6ca25d7d745a6e3edfff9fa88c`.
- Final candidate3, guarded ordinary-range legacy path plus candidate2 slow
  path: math SHA256
  `d87cbb366be2a318a72090ff1bc1f02896933843dbe93857ba7378e42bfe1489`.
  Local source-carrier branch `fix/smooth-extrema-fast-guard`, commit
  `f5cedc5626a364c0228f921d9ce58ba33a6ada02` (tree
  `7fe555042a8be3b59559a79153b4543b5acf7797`), changes only
  `newton/_src/math/__init__.py`, `newton/tests/test_math.py`, and the
  `changelog/+smooth-extrema-finite-7c2f91a4.fixed.md` fragment. Final test
  SHA256 `c5cebaf808821f731cee3b2b5c1737a0b7a5cabbe89eeac31713602c4567599c`;
  fragment SHA256 `7595e003243f458be799e1dd73d53dd67ee70e9d58cf2e07b56013cf854e10c6`.
  The intermediate candidate2 math diff needed to recreate its cost result
  is bundled separately as `candidate2-math.patch` SHA256
  `6e05361da4fb7eea9e99d58ef7ca08453c24e922ee1cd787ea9318da7315dd69`.
- The guard uses `|a|,|b| <= 2^62` and `2^-126 <= eps <= 2^126`.
  Therefore `|a±b| <= 2^63` and `(a-b)^2+eps <= 2^127`, below the Float32
  maximum; the final half-sum/square-root expression also remains finite.
  Positive subnormal eps takes the scaled path so the smoothing width is not
  erased. This is an overflow proof, **not** a correct-rounding proof.
  Guarded values exactly retain baseline arithmetic, including its inherited
  finite cancellation error; candidate3 does not preserve every precision
  improvement of candidate2. For example, the baseline expression for
  `smooth_min(2^60, 1, 1e-5)` rounds to `0` although the mathematical result
  rounds to `1`, and candidate3 retains that legacy result inside the guard.
  This example follows from the formula and is not a separately recorded
  Warp runtime test. At `eps<=0`, forward behavior is verbatim
  baseline; no out-of-domain derivative promise is made.
- Frozen shipping regression tests replayed against unedited baseline:
  5 tests, six failing assertions/subtests, zero errors, receipt
  `candidate3-shipping-test-on-baseline.log` SHA256
  `d2f5b073e00f269b4446716b914fd2d32e40bb4e1bf1226e6e28c5a7bae9fc4d`.
  Candidate3 math suite: 8/8 PASS, receipt `candidate3-math-boundaries.log`
  SHA256 `708b138c76cce2ccd87aa3e8e6a6aac7f5f475c8017074d9561bcf31c89ca1a9`.
  Small actual CPU XPBD prismatic caller test: 1/1 PASS, receipt
  `candidate3-xpbd-prismatic.log` SHA256
  `8cb3a31d95209ec5db6d1df7d93e0cbe0db6d89cd8e713baf9c3567a2e20dd83`.
- Independent critic froze a 42-case Decimal220 oracle before candidate2
  review (`../critic/analytic_oracle_boundary_frozen.json`, SHA256
  `4b76e376ef0304fecad0029e868b4f5358c3bab2be19887cf35a7bf597481086`),
  and a 77-case exact-Float32 guard-seam oracle before candidate3 edit
  (`../critic/guard_oracle_frozen.json`, SHA256
  `c6e50792abf83f193b69929de0a1a757aa33341e82b24b2439125a24cdc39774`).
  Candidate3 passes original 42 / four public functions / three Warp Tape
  gradients (receipt `candidate3-independent42.log`, SHA256
  `4a15325d8e9a456cbcb81e6b43f24c55c79d0e00dca94cd03c343b1114980c2d`)
  and all 77 seam cases with strict eps-gradient rtol `2e-5`, atol `0`
  (receipt `independent-guard-candidate3-d87cbb36.log`, SHA256
  `c897a45235ceb1a5c4bbe3830a2305e6e1387ffee43ca21cef6812cdeb7d166f`).
  All 240 fast-path case/function value+gradient pairs bit-match baseline;
  all 68 slow-path pairs bit-match candidate2. Eight nonpositive-eps forward
  controls bit-match baseline (`independent-guard-path-comparison.log`, SHA256
  `33ad401f00ab247bf7c61271f04e6470fc51f4b77c990c7cf6164b996ebdf9bf`).

## Frozen CPU cost comparison

The plan `cpu-cost-plan-frozen.md` (SHA256
`f5c55e7e1fa53c21eff697cc94a59e35ffea8e596a36ca520854dbb45e1821f2`)
preceded timing. The candidate2 harness `bench_cpu_cost.py` (SHA256
`864cc8a212c236aca9ddc406e7574bdc03c06d503c81aef7b8b0884ea710759c`)
and candidate3 harness `bench_cpu_cost_candidate3.py` (SHA256
`30a1bc23875e540f743a5d0489ede0016d596a4c61e75f3107f520168368beb8`)
differ in exactly one source-selector path/hash line. Inputs, validation,
timing, warmups, ABBA order, and 131072-item workload are unchanged. Each
run used pinned Warp 1.18.0 on CPU; compilation and warmup were excluded.
The dynamic-eps scalar kernel and the exact fixed-eps XPBD leaky correction
expression both passed a Float64 analytic output check in all 12 processes.

| Kernel | Candidate2 baseline/candidate median | Candidate2 paired C/B by ABBA cycle | Candidate3 baseline/candidate median | Candidate3 paired C/B by ABBA cycle |
|---|---:|---|---:|---|
| Dynamic-eps smooth scalar | 1.034 / 1.648 ms | 1.40, 1.73, 1.37 | 1.060 / 1.327 ms | 1.01, 1.28, 1.51 |
| Fixed-eps XPBD vec-leaky expression | 1.527 / 3.925 ms | 2.56, 2.51, 2.37 | 1.684 / 2.058 ms | 1.28, 1.11, 1.24 |

All per-launch raw timings, six process medians per source, process order,
output hashes, and p10/p90 are in `bench-cpu-cost-run.log` SHA256
`bed2fb5d1c4668cd5bc157dca4c8c2a3705d297ed37949faf4018f5b8422b835`
and `bench-cpu-cost-candidate3.log` SHA256
`d37c71d7c32cf5d6fd708ef66ab2814bb56bae0abca5b7a303acc5db17fe3415`.
These small CPU samples are descriptive, not CI bounds or statistical proof.
Candidate3 pre/post host metadata (`candidate3-host-metadata-pre.txt` and
`candidate3-host-metadata-post.txt`) record Python 3.12.14, NumPy 2.3.5,
Warp 1.18.0, Linux 6.18.44, Xeon Platinum 8573C, affinity CPUs 0-8, and
load averages. Candidate2-era affinity/load snapshots were not captured and
are unavailable. GPU behavior and whole-solver speed were **not measured**.

## Reproduction / review limits

The official source `uv.lock` SHA256 is
`2fd42c5c2cf62f8750b191dd01cc1a196a4a3e43a27b42f94b04bcd2e2b24b5a`.
The pinned Warp 1.18.0 wheel hash is
`090962bfae7dd22ade0d8e0258f41635e0e58980f15bcc9e7a7d312819dfe440`
(`../warp-requirements.txt` SHA256
`99e6798f975245aa69e9914e3fbf3e570a4c2634f9e50e545d197bb5114a4321`).
Warp came from the official NVIDIA PyPI index and was installed with
wheel hash enforcement into the isolated `red-test/.venv`; runtime caches
were kept under `uv-cache/` and `warp-cache/`. Re-run each receipt's command
in the appropriate baseline, `feature/`, or `candidate3/` worktree with that
venv, `PYTHONPATH` pointing to the worktree, and `WARP_CACHE_PATH` pointing to
the isolated cache. The independent critic commands are in
`../critic/independent-replay-command.txt` and `../critic/independent-guard-command.txt`.
To reconstruct the three benchmark source siblings after the separate final
source commit is published, first create fresh checkouts at the pinned
parent as `red-test/` and `feature/`, and check out final commit
`f5cedc5626a364c0228f921d9ce58ba33a6ada02` as `candidate3/`.
Then extract this evidence archive over their shared parent directory;
it adds public test helpers under `red-test/` and `feature/`, so extracting
it *before* creating those checkouts would leave nonempty target directories.
Apply `receipts/candidate2-math.patch` to `feature/`.
Verify the math source SHA256 values above before running the two benchmark
scripts from `receipts/`. The benchmark harness expects these three siblings
beside `receipts/` and uses the same deterministic inputs in each process.
Its CPU times are hardware/load dependent; the preserved raw samples and
analytic output checks are the evidence for this run.

Ruff 0.16.10 check/format, direct applicable pre-commit-hooks 6.0.0 checks,
Warp-array syntax, `git diff --check`, and Towncrier 25.8.0 preview pass.
The repo-required unskipped full gate also passed in a fresh disposable
worktree containing byte-identical candidate3 source/test/fragment, with
official `pre-commit==4.3.0` and the repo-pinned hook revisions:
`uvx --from pre-commit==4.3.0 pre-commit run -a`. Its `uv-lock`, typos,
Ruff, Warp syntax, and other applicable hooks passed; Windows filename and
symlink checks were skipped by pre-commit because no files matched.
`uv.lock` and all three candidate files were byte-identical before/after,
with zero new unstaged/untracked files. The full log is
`hookcheck-precommit-full.log`, original SHA256
`cd6945b037334e3aa503c8b5015ac9ae9ce151f3f2a0aff7f2122a764bac324b`.
Basedpyright was not run; it is configured but not a repo pre-commit hook.
No GPU or broad unrelated solver suite was run. At evidence capture, before
downstream publication, no source had been pushed and no upstream
communication had been made.

The separate public evidence bundle uses an explicit file allowlist. Only
absolute sandbox/runtime path prefixes in copied logs and command receipts
are normalized to placeholders; numerical/result lines are unchanged.
Original hashes above refer to the local raw files. The bundled
`evidence-manifest.json` records each portable file's SHA256, its original
SHA256, and a hash of unchanged result lines for logs. No cache, binary,
private file, or source worktree is in the evidence bundle; the source branch
is a separate carrier.
