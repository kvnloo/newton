"""Frozen CPU-only cost probe for smooth extrema and the XPBD leaky pattern."""

import argparse
import hashlib
import json
import os
import pathlib
import statistics
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
SOURCES = {
    "B": (ROOT / "red-test", "3d2196cfda9268410044efc24515c2f5b6a9bf661281c67f9c4941967a1f7531"),
    "C": (ROOT / "feature", "005c714a257915a32b01cc10358976bfb5926f6ca25d7d745a6e3edfff9fa88c"),
}
N = 131_072
SEED = 20261010
WARMUPS = 10
SAMPLES = 21


def sha256(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def analytic_max(a, b, eps):
    import numpy as np

    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    eps = np.asarray(eps, dtype=np.float64)
    return 0.5 * (a + b + np.sqrt((a - b) ** 2 + eps))


def analytic_min(a, b, eps):
    import numpy as np

    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    eps = np.asarray(eps, dtype=np.float64)
    return 0.5 * (a + b - np.sqrt((a - b) ** 2 + eps))


def worker(label):
    import numpy as np
    import warp as wp

    import newton.math as nm

    source, expected_hash = SOURCES[label]
    actual_hash = sha256(source / "newton/_src/math/__init__.py")
    assert actual_hash == expected_hash, (label, actual_hash)
    assert pathlib.Path(nm.__file__).resolve().is_relative_to(source.resolve()), nm.__file__

    @wp.kernel(enable_backward=False)
    def scalar_kernel(a: wp.array[wp.float32], b: wp.array[wp.float32], eps: wp.array[wp.float32],
                      out_max: wp.array[wp.float32], out_min: wp.array[wp.float32]):
        i = wp.tid()
        out_max[i] = nm.smooth_max(a[i], b[i], eps[i])
        out_min[i] = nm.smooth_min(a[i], b[i], eps[i])

    @wp.kernel(enable_backward=False)
    def xpbd_pattern_kernel(dx: wp.array[wp.vec3], lower: wp.array[wp.float32], upper: wp.array[wp.float32],
                            out_corr: wp.array[wp.vec3]):
        i = wp.tid()
        axis = wp.vec3(1.0, 0.0, 0.0)
        lower_pos_limits = axis * lower[i]
        upper_pos_limits = axis * upper[i]
        corr = wp.vec3(0.0)
        zero = wp.vec3(0.0)
        corr -= nm.vec_leaky_min(zero, upper_pos_limits - dx[i])
        corr -= nm.vec_leaky_max(zero, lower_pos_limits - dx[i])
        out_corr[i] = corr

    rng = np.random.default_rng(SEED)
    a = rng.uniform(-2.0, 2.0, N).astype(np.float32)
    b = rng.uniform(-2.0, 2.0, N).astype(np.float32)
    b[::8] = a[::8]
    eps = rng.choice(np.asarray([1e-5, 1e-3, 1e-1], dtype=np.float32), size=N)
    dx = rng.uniform(-3.0, 3.0, (N, 3)).astype(np.float32)
    lower = rng.uniform(-2.0, -0.5, N).astype(np.float32)
    upper = rng.uniform(0.5, 2.0, N).astype(np.float32)
    aw = wp.array(a, dtype=wp.float32, device="cpu")
    bw = wp.array(b, dtype=wp.float32, device="cpu")
    ew = wp.array(eps, dtype=wp.float32, device="cpu")
    dxw = wp.array(dx, dtype=wp.vec3, device="cpu")
    lowerw = wp.array(lower, dtype=wp.float32, device="cpu")
    upperw = wp.array(upper, dtype=wp.float32, device="cpu")
    outmax = wp.empty(N, dtype=wp.float32, device="cpu")
    outmin = wp.empty(N, dtype=wp.float32, device="cpu")
    outcorr = wp.empty(N, dtype=wp.vec3, device="cpu")

    def run_scalar():
        wp.launch(scalar_kernel, dim=N, inputs=[aw, bw, ew], outputs=[outmax, outmin], device="cpu")

    def run_xpbd():
        wp.launch(xpbd_pattern_kernel, dim=N, inputs=[dxw, lowerw, upperw], outputs=[outcorr], device="cpu")

    results = {}
    for name, run in (("scalar", run_scalar), ("xpbd_pattern", run_xpbd)):
        for _ in range(WARMUPS):
            run()
            wp.synchronize_device("cpu")
        durations = []
        for _ in range(SAMPLES):
            start = time.perf_counter_ns()
            run()
            wp.synchronize_device("cpu")
            durations.append(time.perf_counter_ns() - start)
        results[name] = {"raw_ns": durations, "median_ns": statistics.median(durations)}

    actual_max = outmax.numpy()
    actual_min = outmin.numpy()
    actual_corr = outcorr.numpy()
    ref_max = analytic_max(a, b, eps)
    ref_min = analytic_min(a, b, eps)
    limits_upper = np.zeros_like(dx, dtype=np.float64)
    limits_lower = np.zeros_like(dx, dtype=np.float64)
    limits_upper[:, 0] = upper
    limits_lower[:, 0] = lower
    ref_corr = -analytic_min(0.0, limits_upper - dx.astype(np.float64), 1e-5)
    ref_corr -= analytic_max(0.0, limits_lower - dx.astype(np.float64), 1e-5)
    for name, actual, ref in (("max", actual_max, ref_max), ("min", actual_min, ref_min),
                              ("xpbd_corr", actual_corr, ref_corr)):
        assert np.all(np.isfinite(actual)), name
        np.testing.assert_allclose(actual, ref, rtol=2e-5, atol=1e-6)
        results[name + "_check"] = {
            "max_abs_err": float(np.max(np.abs(actual - ref))),
            "sha256": hashlib.sha256(actual.tobytes()).hexdigest(),
        }
    results.update({"label": label, "source_hash": actual_hash, "n": N, "seed": SEED,
                    "warmups": WARMUPS, "samples": SAMPLES, "device": "cpu", "warp_version": wp.__version__})
    print("BENCH_JSON=" + json.dumps(results, sort_keys=True), flush=True)


def orchestrate():
    import numpy as np

    order = "BCCB" * 3
    records = []
    for index, label in enumerate(order):
        source, expected_hash = SOURCES[label]
        assert sha256(source / "newton/_src/math/__init__.py") == expected_hash
        env = dict(os.environ, PYTHONPATH=str(source), WARP_CACHE_PATH=str(ROOT / "warp-cache"))
        command = [sys.executable, str(pathlib.Path(__file__).resolve()), "--worker", label]
        proc = subprocess.run(command, cwd=source, env=env, text=True, capture_output=True)
        print(f"RUN={index} LABEL={label} EXIT={proc.returncode}", flush=True)
        print(proc.stdout, flush=True)
        print(proc.stderr, file=sys.stderr, flush=True)
        if proc.returncode != 0:
            raise SystemExit(proc.returncode)
        record = json.loads([line[11:] for line in proc.stdout.splitlines() if line.startswith("BENCH_JSON=")][-1])
        record["index"] = index
        records.append(record)
    summary = {}
    for name in ("scalar", "xpbd_pattern"):
        source_medians = {label: [r[name]["median_ns"] for r in records if r["label"] == label]
                          for label in SOURCES}
        cycle_ratios = []
        for cycle in range(3):
            four = records[cycle * 4:cycle * 4 + 4]
            base = [r[name]["median_ns"] for r in four if r["label"] == "B"]
            cand = [r[name]["median_ns"] for r in four if r["label"] == "C"]
            cycle_ratios.append(float(np.sqrt(cand[0] * cand[1] / (base[0] * base[1]))))
        summary[name] = {"process_medians_ns": source_medians,
                         "pooled_median_ns": {k: statistics.median(v) for k, v in source_medians.items()},
                         "p10_p90_process_ns": {k: np.percentile(v, [10, 90]).tolist() for k, v in source_medians.items()},
                         "cycle_ratios_candidate_over_baseline": cycle_ratios}
    print("SUMMARY_JSON=" + json.dumps(summary, sort_keys=True), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", choices=SOURCES)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
    else:
        orchestrate()
