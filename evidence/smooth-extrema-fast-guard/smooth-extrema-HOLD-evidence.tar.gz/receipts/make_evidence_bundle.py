"""Package an explicit set of public-text numerical evidence files."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent.parent
ALLOWLIST = ROOT / "receipts/evidence-public-allowlist.txt"
OUTPUT = ROOT / "smooth-extrema-HOLD-evidence.tar.gz"
ALLOWED_SUFFIXES = {".txt", ".md", ".py", ".json", ".log", ".patch"}
REPLACEMENTS = (
    ("NEWTON_NEXT", str(ROOT).encode(), b"{NEWTON_NEXT}"),
    ("PYTHON_RUNTIME", b"/opt/codex/runtimes/codex-primary-runtime", b"{PYTHON_RUNTIME}"),
)
RESULT_PREFIXES = (
    b"BENCH_JSON=", b"SUMMARY_JSON=", b"VALUE ", b"GRAD ",
    b"FAILURE_COUNT ", b"FAILURES ", b"COMPATIBILITY_VALUES ",
    b"BASELINE_FINAL_TEST_RUN=", b"CANDIDATE3_", b"FULL_PRECOMMIT_EXIT=",
    b"XPBD_PRISMATIC_EXIT=", b"FINAL_MATH_EXIT=",
)
FORBIDDEN_PATHS = (b"/workspace/scratch/", b"/root/", b"/home/", b"/tmp/")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def result_lines(data):
    return b"".join(line for line in data.splitlines(keepends=True) if line.startswith(RESULT_PREFIXES))


def tar_item(name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = 0o644
    info.mtime = 0
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    return info, io.BytesIO(data)


def main():
    selected = []
    for line in ALLOWLIST.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            selected.append(line)
    assert len(selected) == len(set(selected))
    entries = []
    payloads = {}
    for rel in selected:
        rel_path = Path(rel)
        assert not rel_path.is_absolute() and ".." not in rel_path.parts
        assert rel_path.suffix in ALLOWED_SUFFIXES
        assert rel_path.parts[0] in {"receipts", "critic", "red-test", "feature"} or rel == "warp-requirements.txt"
        source = ROOT / rel_path
        assert source.is_file() and not source.is_symlink(), rel
        raw = source.read_bytes()
        raw.decode("utf-8")
        assert b"\x00" not in raw
        portable = raw
        counts = {}
        if rel_path.suffix in {".log", ".txt"}:
            for label, old, new in REPLACEMENTS:
                counts[label] = portable.count(old)
                portable = portable.replace(old, new)
        if rel != "receipts/make_evidence_bundle.py":
            for forbidden in FORBIDDEN_PATHS:
                assert forbidden not in portable, (rel, forbidden)
        else:
            # This public validator necessarily spells the path patterns it
            # rejects, but it must not embed the actual workspace prefix.
            assert str(ROOT).encode() not in portable
        if rel != "receipts/make_evidence_bundle.py":
            assert b"PRIVATE KEY-----" not in portable, rel
        raw_results = result_lines(raw)
        portable_results = result_lines(portable)
        assert raw_results == portable_results, rel
        payloads[rel] = portable
        entries.append({
            "path": rel,
            "original_sha256": digest(raw),
            "portable_sha256": digest(portable),
            "normalized_prefix_counts": {k: v for k, v in counts.items() if v},
            "result_lines_sha256": digest(raw_results) if raw_results else None,
            "result_line_count": len(raw_results.splitlines()),
        })
    manifest = {
        "purpose": "Portable public-text HOLD evidence; source carrier is separate",
        "upstream_parent": "a6e1649b112e3d962b35f7dad66780dc55150588",
        "candidate3_commit": "f5cedc5626a364c0228f921d9ce58ba33a6ada02",
        "candidate3_tree": "7fe555042a8be3b59559a79153b4543b5acf7797",
        "normalization": [
            {"prefix_label": label, "replacement": new.decode()}
            for label, _, new in REPLACEMENTS
        ],
        "files": entries,
    }
    payloads["receipts/evidence-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with OUTPUT.open("wb") as target:
        with gzip.GzipFile(fileobj=target, mode="wb", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w") as archive:
                for rel, data in sorted(payloads.items()):
                    info, stream = tar_item(rel, data)
                    archive.addfile(info, stream)
    print("OUTPUT", OUTPUT)
    print("SHA256", digest(OUTPUT.read_bytes()))
    print("FILES", len(payloads))
    print("BYTES", OUTPUT.stat().st_size)


if __name__ == "__main__":
    main()
