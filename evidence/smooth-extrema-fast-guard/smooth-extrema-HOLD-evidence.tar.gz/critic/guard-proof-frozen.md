# Candidate3 guard proof and pre-implementation controls

Candidate2 remains the unmodified slow path. The proposed fast path uses the verbatim original expression only when:

- `abs(a) <= 2^62` and `abs(b) <= 2^62`
- `2^-126 <= eps <= 2^126`

These are representability-based Float32 limits, rather than bounds selected from benchmark inputs. In particular, normal XPBD default limits at `MAXVAL=1e10` remain eligible, while positive subnormal epsilon stays on the robust slow path.

## Finite intermediates

Let `L=2^62`. With round-to-nearest Float32 arithmetic:

1. `|a-b| <= 2L = 2^63` and `|a+b| <= 2^63`. These exact upper bounds are representable, so rounding cannot exceed them.
2. `(a-b)^2 <= 2^126`; adding `eps <= 2^126` gives a radicand no larger than `2^127`, also exactly representable.
3. The square root is no larger than the rounded value of `sqrt(2^127)`. Even allowing its last-bit rounding, `|a+b| + sqrt(radicand) < 2^65`, vastly below Float32 overflow.
4. The radicand is at least the minimum normal Float32 value `2^-126`, so its square root is positive and at least `2^-63`.
5. For unit-seed reverse-mode derivatives, the square-root reciprocal is no larger than `2^63`. Even loose independent bounds on each multiplication/addition in the legacy adjoint stay below Float32 overflow. The actual analytic gradients with respect to a and b lie in [0,1]; the epsilon derivative is bounded by `2^61`.

This proves safety of the legacy intermediate arithmetic on the guard. It does not promise correct rounding or exact tiny-cancellation recovery. For example, legacy `smooth_min(128,0,1e-5)` may produce zero instead of a small negative correction. That is unchanged baseline behavior, accepted by the original bounded approximate-value contract; candidate3 must not claim to preserve candidate2's improved cancellation accuracy everywhere.

## Branch derivatives

Both formulas represent the same exact smooth function for positive epsilon. Thus there is no mathematical derivative discontinuity at the guard boundary. Warp selects the active branch's adjoint; controls compare both sides and the exact seam to the same independent analytic derivatives. Floating roundoff can differ across the seam and is bounded by explicit tolerances, not claimed to vanish.

## Frozen controls

`guard_oracle_frozen.json` was generated before candidate3 implementation, with 220-digit Decimal arithmetic and exact Float32 input conversion.

SHA256: `c6e50792abf83f193b69929de0a1a757aa33341e82b24b2439125a24cdc39774`
Generator SHA256: `e52821defc3e5e51c3caf8a43eb3daf6f7e479aeee2dddb499997a279d9b3d8a`

There are 77 cases. Each includes analytic values, correctly Float32-rounded reference values, and gradients with respect to a, b, and epsilon.

- Input boundary `0x5e800000` (2^62), one ULP below/on/above, both signs, both arguments, swaps, exact ties including ±2^62, and opposite-sign pairs.
- Epsilon lower boundary `0x00800000` (2^-126) and upper boundary `0x7e800000` (2^126), one ULP below/on/above. Includes zero/unit/large ties, large opposite/sign-swapped operands, and the lower-bound scaling crossover.
- Ordinary cancellation-tail controls at 128 and actual default XPBD scale 1e10.

Pre-set tolerances:

- Forward: `8 * Float32 machine epsilon * max(abs(a),abs(b),sqrt(eps))`, finite required.
- a and b gradients: `rtol=1e-5`, `atol=1e-6`, finite required.
- epsilon gradient for these guard controls: `rtol=2e-5`, `atol=0`, finite required. These reference derivatives are normal, so the original far-tail absolute allowance is unnecessary and must not mask seam-specific derivative loss.

The original 42-case frozen positive-epsilon gate, ordinary controls, and nonpositive-epsilon compatibility controls remain unchanged. No source replay or cost timing was performed by this critic while freezing this design and oracle. Candidate2, the original baseline, original cost thresholds, and failed cost evidence must remain preserved.
