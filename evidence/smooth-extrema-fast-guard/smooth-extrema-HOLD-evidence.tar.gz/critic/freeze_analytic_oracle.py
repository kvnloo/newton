"""Freeze a high-precision reference independently of any Newton candidate.

This is analytic oracle generation only: no Newton/Warp import or execution.
"""
import decimal
import hashlib
import json
import math
import pathlib
import struct

D = decimal.Decimal
decimal.getcontext().prec = 220

def f32(x):
    return struct.unpack('!f', struct.pack('!f', x))[0]

def from_bits(bits):
    return struct.unpack('!f', struct.pack('!I', bits))[0]

def bits(x):
    return f'{struct.unpack("!I", struct.pack("!f", x))[0]:08x}'

F = from_bits(0x7f7fffff)
S = from_bits(1)
N = from_bits(0x00800000)
C = 2.0**-10
cases = [
 ('ordinary', 2., 1., 1e-5), ('ordinary_swap', 1., 2., 1e-5),
 ('ordinary_negative', -2., -1., 1e-5), ('ordinary_equal', 2., 2., 1e-5),
 ('origin', 0., 0., 1e-5), ('ordinary_opposite', 1., -1., 1e-5),
 ('square_overflow', 1e20, 0., 1e-5), ('square_overflow_swap', 0., 1e20, 1e-5),
 ('negative_square_overflow', -1e20, 0., 1e-5),
 ('large_equal', 2e38, 2e38, 1e-5), ('large_equal_negative', -2e38, -2e38, 1e-5),
 ('large_opposite', 2e38, -2e38, 1e-5), ('large_opposite_swap', -2e38, 2e38, 1e-5),
 ('large_unequal', 2e38, 1e38, 1e-5), ('large_unequal_negative', -2e38, -1e38, 1e-5),
 ('maximum_equal', F, F, 1e-5), ('maximum_negative_equal', -F, -F, 1e-5),
 ('maximum_opposite', F, -F, 1e-5), ('maximum_zero', F, 0., 1e-5),
 ('maximum_half', F, f32(F/2), 1e-5),
 ('maximum_unequal_near', F, from_bits(0x7f7ffffe), 1e-5),
 ('maximum_unequal_far', F, from_bits(0x7f000001), 1e-5),
 ('crossover', C, 0., 2.**-20), ('crossover_swap', 0., C, 2.**-20),
 ('crossover_below', from_bits(0x3a7fffff), 0., 2.**-20),
 ('crossover_above', from_bits(0x3a800001), 0., 2.**-20),
 ('crossover_negative', -C, 0., 2.**-20),
 ('tiny_eps_origin', 0., 0., 1e-30), ('tiny_eps_equal', 2., 2., 1e-30),
 ('min_normal_eps_origin', 0., 0., N), ('min_subnormal_eps_origin', 0., 0., S),
 ('min_subnormal_eps_equal', 2., 2., S),
 ('subnormal_inputs', S, -S, S), ('subnormal_inputs_equal', S, S, S),
 ('tiny_eps_large_opposite', 2e38, -2e38, S),
 ('normal_inputs_tiny_eps', 1e-20, -1e-20, S),
]
cutoff = D.from_float(F) + D(2)**103
records=[]
for label,a,b,e in cases:
    a,b,e = map(f32, (a,b,e))
    da,db,de = map(D.from_float, (a,b,e))
    delta = da-db
    root = (delta*delta+de).sqrt()
    plus=(da+db+root)/2
    minus=(da+db-root)/2
    ga=(1+delta/root)/2
    gb=(1-delta/root)/2
    ge=1/(4*root)
    records.append(dict(label=label, a=a,b=b,eps=e,
        input_bits=[bits(x) for x in (a,b,e)],
        smooth_max=str(plus),smooth_min=str(minus),
        rounded_float32=[f32(float(x)) for x in (plus,minus)],
        requires_float32_result_overflow=[abs(x)>=cutoff for x in (plus,minus)],
        smooth_max_grad=[str(x) for x in (ga,gb,ge)],
        smooth_min_grad=[str(x) for x in (gb,ga,-ge)],
        forward_test_scale=float(max(abs(da),abs(db),de.sqrt()))))
result=dict(purpose='Independent analytic positive-eps control freeze; no candidate execution',
 precision=220, source_commit='a6e1649b112e3d962b35f7dad66780dc55150588',
 contract='Docs promise a close differentiable approximation for small positive eps, but specify no exact tolerance or correct rounding. Require finite results and finite unit-seed derivatives on these cases. Compare forward at input-scale tolerance; do not demand recovery of tiny cancellation residuals.',
 suggested_forward_tolerance='8 * float32_epsilon * forward_test_scale; tighten ordinary-scale controls where suitable',
 suggested_gradient_tolerance='rtol=1e-5, atol=1e-6; requires real reverse-mode Tape, not finite difference',
 invariants=['Symmetry under argument swap', 'grad_a + grad_b = 1', 'gradients wrt a,b in [0,1] within rounding', 'smooth_max_grad_eps > 0, smooth_min_grad_eps < 0 where resolvable'],
 records=records)
path=pathlib.Path(__file__).with_name('analytic_oracle_frozen.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print('cases',len(records))
print('oracle_sha256',hashlib.sha256(path.read_bytes()).hexdigest())
print('generator_sha256',hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
print('all_selected_results_round_finite',not any(any(r['requires_float32_result_overflow']) for r in records))
print('min_subnormal_eps_origin',next(r for r in records if r['label']=='min_subnormal_eps_origin'))
