"""Freeze a high-precision reference independently of any Newton candidate.

This is analytic oracle generation only: no Newton/Warp import or execution.
"""
import decimal
import hashlib
import json
import math
import pathlib
import struct

D = decimal.Decimal
decimal.getcontext().prec = 220

def f32(x):
    return struct.unpack('!f', struct.pack('!f', x))[0]

def from_bits(bits):
    return struct.unpack('!f', struct.pack('!I', bits))[0]

def bits(x):
    return f'{struct.unpack("!I", struct.pack("!f", x))[0]:08x}'

F = from_bits(0x7f7fffff)
S = from_bits(1)
N = from_bits(0x00800000)
C = 2.0**-10
L = 2.0**62
cases = []
for label, value in [('below',from_bits(0x5e7fffff)),('on',from_bits(0x5e800000)),('above',from_bits(0x5e800001))]:
    for sign_name, sign in [('pos',1.),('neg',-1.)]:
        v=sign*value
        for pair_name, a, b in [('a',v,0.),('b',0.,v),('tie',v,v),('opposite',v,-sign*L),('opposite_swap',-sign*L,v)]:
            cases.append((f'input_{label}_{sign_name}_{pair_name}',a,b,1e-5))
for bound_name, center in [('eps_low',0x00800000),('eps_high',0x7e800000)]:
    for offset_name, offset in [('below',-1),('on',0),('above',1)]:
        e=from_bits(center+offset)
        pairs=[('zero_tie',0.,0.),('unit_tie',2.,2.),('large_tie',L,L),('large_opposite',L,-L),('large_opposite_swap',-L,L)]
        if bound_name=='eps_low':
            pairs += [('crossover',2.**-63,0.),('crossover_swap',0.,2.**-63)]
        else:
            pairs += [('large_zero',L,0.),('zero_large_negative',0.,-L)]
        for pair_name,a,b in pairs:
            cases.append((f'{bound_name}_{offset_name}_{pair_name}',a,b,e))
for label,a,b in [('tail',128.,0.),('tail_swap',0.,128.),('maxval',1e10,0.),('maxval_swap',0.,1e10),('maxval_negative',-1e10,0.)]:
    cases.append((label,a,b,1e-5))
cutoff = D.from_float(F) + D(2)**103
records=[]
for label,a,b,e in cases:
    a,b,e = map(f32, (a,b,e))
    da,db,de = map(D.from_float, (a,b,e))
    delta = da-db
    root = (delta*delta+de).sqrt()
    plus=(da+db+root)/2
    minus=(da+db-root)/2
    ga=(1+delta/root)/2
    gb=(1-delta/root)/2
    ge=1/(4*root)
    records.append(dict(label=label, a=a,b=b,eps=e,
        input_bits=[bits(x) for x in (a,b,e)],
        smooth_max=str(plus),smooth_min=str(minus),
        rounded_float32=[f32(float(x)) for x in (plus,minus)],
        requires_float32_result_overflow=[abs(x)>=cutoff for x in (plus,minus)],
        smooth_max_grad=[str(x) for x in (ga,gb,ge)],
        smooth_min_grad=[str(x) for x in (gb,ga,-ge)],
        forward_test_scale=float(max(abs(da),abs(db),de.sqrt()))))
result=dict(purpose='Independent analytic candidate3 guard-boundary freeze before implementation; no Newton/Warp execution',
 precision=220, source_commit='a6e1649b112e3d962b35f7dad66780dc55150588',
 contract='Docs promise a close differentiable approximation for small positive eps, but specify no exact tolerance or correct rounding. Require finite results and finite unit-seed derivatives on these cases. Compare forward at input-scale tolerance; do not demand recovery of tiny cancellation residuals.',
 suggested_forward_tolerance='8 * float32_epsilon * forward_test_scale; tighten ordinary-scale controls where suitable',
 suggested_gradient_tolerance='a,b: rtol=1e-5, atol=1e-6; eps: rtol=2e-5, atol=0 for these guard cases; requires real reverse-mode Tape, not finite difference',
 invariants=['Symmetry under argument swap', 'grad_a + grad_b = 1', 'gradients wrt a,b in [0,1] within rounding', 'smooth_max_grad_eps > 0, smooth_min_grad_eps < 0 where resolvable'],
 records=records)
path=pathlib.Path(__file__).with_name('guard_oracle_frozen.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print('cases',len(records))
print('oracle_sha256',hashlib.sha256(path.read_bytes()).hexdigest())
print('generator_sha256',hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
print('all_selected_results_round_finite',not any(any(r['requires_float32_result_overflow']) for r in records))
print('guard_boundaries', {'input':L, 'eps_low':N, 'eps_high':2.**126})
