"""Replay frozen independent controls through public Newton functions on CPU."""
import decimal
import hashlib
import json
import os
from pathlib import Path
import sys

import numpy as np
import warp as wp

snapshot = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(snapshot))
import newton

@wp.kernel
def all_extrema(a: wp.array[wp.float32], b: wp.array[wp.float32], e: wp.array[wp.float32], out: wp.array2d[wp.float32]):
    """Evaluate all public scalar smooth extrema with reverse-mode enabled."""
    i = wp.tid()
    out[i, 0] = newton.math.smooth_max(a[i], b[i], e[i])
    out[i, 1] = newton.math.smooth_min(a[i], b[i], e[i])
    out[i, 2] = newton.math.leaky_max(a[i], b[i])
    out[i, 3] = newton.math.leaky_min(a[i], b[i])

@wp.kernel(enable_backward=False)
def compatibility(a: wp.array[wp.float32], b: wp.array[wp.float32], e: wp.array[wp.float32], out: wp.array2d[wp.float32]):
    """Evaluate out-of-positive-epsilon forward controls without derivative claims."""
    i = wp.tid()
    out[i, 0] = newton.math.smooth_max(a[i], b[i], e[i])
    out[i, 1] = newton.math.smooth_min(a[i], b[i], e[i])

D = decimal.Decimal
decimal.getcontext().prec = 220
root = Path(__file__).resolve().parent
oracle_path = root / 'guard_oracle_frozen.json'
oracle = json.loads(oracle_path.read_text())
records = oracle['records']
n = len(records)
values = [np.asarray([r[k] for r in records], dtype=np.float32) for k in ('a', 'b', 'eps')]
args = [wp.array(v, device='cpu', requires_grad=True) for v in values]
out = wp.empty((n, 4), dtype=wp.float32, device='cpu', requires_grad=True)
mathpath = snapshot / 'newton/_src/math/__init__.py'
source_hash = hashlib.sha256(mathpath.read_bytes()).hexdigest()
print('NEWTON_PATH', newton.__file__, flush=True)
print('WARP_VERSION', wp.__version__, flush=True)
print('SOURCE_SHA256', source_hash, flush=True)
print('HARNESS_SHA256', hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), flush=True)
print('ORACLE_SHA256', hashlib.sha256(oracle_path.read_bytes()).hexdigest(), flush=True)
print('COMMAND', sys.argv, flush=True)
with wp.Tape() as tape:
    wp.launch(all_extrema, dim=n, inputs=args, outputs=[out], device='cpu')
got_values = out.numpy()
failures = []
names = ('smooth_max', 'smooth_min', 'leaky_max', 'leaky_min')
refs = np.zeros((n,4), dtype=np.float64)
grad_refs = np.zeros((n,4,3), dtype=np.float64)
scales = np.zeros((n,4), dtype=np.float64)
for i,r in enumerate(records):
    for j in range(4):
        a,b = map(D.from_float, (r['a'],r['b']))
        e = D.from_float(r['eps'] if j<2 else float(np.float32(1e-5)))
        sign = D(1) if j%2 == 0 else D(-1)
        rad = ((a-b)**2 + e).sqrt()
        refs[i,j] = float((a+b+sign*rad)/2)
        grad_refs[i,j] = [float((1+sign*(a-b)/rad)/2),float((1-sign*(a-b)/rad)/2),float(sign/(4*rad)) if j<2 else 0.]
        scales[i,j] = float(max(abs(a),abs(b),e.sqrt()))
        tolerance = 8 * np.finfo(np.float32).eps * scales[i,j]
        if not np.isfinite(got_values[i,j]) or abs(float(got_values[i,j])-refs[i,j]) > tolerance:
            failures.append((r['label'],names[j],'forward'))
    print('VALUE',r['label'],got_values[i].tolist(),refs[i].tolist(),flush=True)
all_gradients=[]
for j,name in enumerate(names):
    tape.zero()
    seed=np.zeros((n,4),dtype=np.float32)
    seed[:,j]=1.
    tape.backward(grads={out:wp.array(seed,device='cpu')})
    got_grad=np.column_stack([x.grad.numpy() for x in args])
    all_gradients.append(got_grad)
    for i,r in enumerate(records):
        target=grad_refs[i,j]
        if (not np.all(np.isfinite(got_grad[i]))
                or not np.allclose(got_grad[i,:2],target[:2],rtol=1e-5,atol=1e-6)
                or not np.isclose(got_grad[i,2],target[2],rtol=2e-5,atol=0)):
            failures.append((r['label'],name,'gradient'))
        print('GRAD',r['label'],name,got_grad[i].tolist(),target.tolist(),flush=True)
compat_rows = [
 (0.,0.,0.),(2.,1.,0.),(2.,2.,-0.),(2.,1.,-1e-5),
 (2.,2.,-1e-5),(2.,1.,-1.),(1e20,0.,0.),(2e38,2e38,-1e-5)
]
compat_arrays=[wp.array(np.asarray([r[k] for r in compat_rows],dtype=np.float32),device='cpu') for k in range(3)]
compat_out=wp.empty((len(compat_rows),2),dtype=wp.float32,device='cpu')
wp.launch(compatibility,dim=len(compat_rows),inputs=compat_arrays,outputs=[compat_out],device='cpu')
compat_values=compat_out.numpy()
print('COMPATIBILITY_ROWS',compat_rows,flush=True)
print('COMPATIBILITY_VALUES',compat_values.tolist(),flush=True)
assert hashlib.sha256(mathpath.read_bytes()).hexdigest() == source_hash, 'Source changed during replay'
np.savez(root/f'guard-{snapshot.name}-results.npz', values=got_values, gradients=np.stack(all_gradients,axis=1), compatibility=compat_values)
print('FAILURE_COUNT',len(failures),flush=True)
print('FAILURES',failures,flush=True)
raise SystemExit(bool(failures))
