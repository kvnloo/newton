"""Frozen CPU-only public-API reproduction for finite smooth extrema."""

import numpy as np
import warp as wp

import newton


@wp.kernel(enable_backward=False)
def evaluate(
    a: wp.array(dtype=wp.float32),
    b: wp.array(dtype=wp.float32),
    smooth_hi: wp.array(dtype=wp.float32),
    smooth_lo: wp.array(dtype=wp.float32),
    leaky_hi: wp.array(dtype=wp.float32),
    leaky_lo: wp.array(dtype=wp.float32),
):
    i = wp.tid()
    smooth_hi[i] = newton.math.smooth_max(a[i], b[i], 1.0e-5)
    smooth_lo[i] = newton.math.smooth_min(a[i], b[i], 1.0e-5)
    leaky_hi[i] = newton.math.leaky_max(a[i], b[i])
    leaky_lo[i] = newton.math.leaky_min(a[i], b[i])


def main():
    # Positive eps throughout: ordinary control, overflowing square,
    # argument swap, and overflowing sum with a finite exact result.
    a = np.array([2.0, 1.0e20, 0.0, 2.0e38], dtype=np.float32)
    b = np.array([1.0, 0.0, 1.0e20, 2.0e38], dtype=np.float32)
    outputs = [wp.empty(len(a), dtype=wp.float32, device="cpu") for _ in range(4)]
    wp.launch(
        evaluate,
        dim=len(a),
        inputs=[wp.array(a, device="cpu"), wp.array(b, device="cpu"), *outputs],
        device="cpu",
    )
    names = ("smooth_max", "smooth_min", "leaky_max", "leaky_min")
    values = [output.numpy() for output in outputs]
    for name, result in zip(names, values, strict=True):
        print(f"{name}: {result.tolist()}", flush=True)

    # This finite, ordinary-scale control is within the documented approximation.
    for result, target in zip(values, (2.0, 1.0, 2.0, 1.0), strict=True):
        np.testing.assert_allclose(result[0], target, rtol=1.0e-5, atol=1.0e-5)

    # Exact smooth extrema remain finite for these inputs. At wide separation
    # they round to the hard extrema in float32; no tiny-cancellation claim.
    expected = (np.maximum(a, b), np.minimum(a, b))
    for name, result, target in zip(names, values, (*expected, *expected), strict=True):
        assert np.isfinite(result).all(), f"{name} yielded a non-finite value for finite inputs"
        np.testing.assert_allclose(result, target, rtol=1.0e-5, atol=1.0e-5)


if __name__ == "__main__":
    main()
