"""New independent finite-float32 counterexamples, frozen before three-arm replay.

This is new evidence. The historical three regressions/34 probes were unavailable.
The oracle uses 200-digit Decimal weighted sums and analytic derivatives, with
the exact float32 dominant-input limit only where |alpha*(a-b)| > 800.
No candidate-specific expected values, source-text assertions or performance work.
"""

import argparse
import hashlib
import json
import math
from decimal import Decimal, localcontext
from pathlib import Path
import unittest

import numpy as np
import warp as wp
import newton


RECORDS = []
FMAX = np.finfo(np.float32).max
NORMAL_MIN = np.finfo(np.float32).tiny


@wp.kernel
def evaluate_public(a: wp.array[float], b: wp.array[float], alpha: wp.array[float], out: wp.array[float]):
    """Evaluate the public helper in an actual native Warp kernel."""
    i = wp.tid()
    out[i] = newton.math.boltzmann(a[i], b[i], alpha[i])


def reference(case):
    """Derive the mean and three first derivatives independently in Decimal."""
    with localcontext() as ctx:
        ctx.prec = 200
        ctx.Emax = 10000000
        ctx.Emin = -10000000
        a, b, k = [Decimal.from_float(float(x)) for x in case]
        d = a - b
        x = k * d
        if abs(x) > 800:
            # Every discarded value/derivative term is below float32 range:
            # d^2 <= 4*FLT_MAX^2 and exp(-800) < 4e-348.
            return (float(a), [1.0, 0.0, 0.0]) if x > 0 else (float(b), [0.0, 1.0, 0.0])
        # Shift both exponent arguments by the same exact Decimal quantity.
        # Evaluate the defining weighted sum, not either candidate's correction.
        shift = max(k * a, k * b)
        ea, eb = (k * a - shift).exp(), (k * b - shift).exp()
        total = ea + eb
        pa, pb = ea / total, eb / total
        value = (a * ea + b * eb) / total
        cross = k * pa * pb * d
        return float(value), [float(pa + cross), float(pb - cross), float(pa * pb * d * d)]


def public_results(cases, label):
    """Record forward results and reverse-mode gradients without scalar emulation."""
    rows = np.asarray(cases, dtype=np.float32)
    operands = [wp.array(rows[:, i], dtype=float, device="cpu", requires_grad=True) for i in range(3)]
    out = wp.empty(len(rows), dtype=float, device="cpu", requires_grad=True)
    with wp.Tape() as tape:
        wp.launch(evaluate_public, dim=len(rows), inputs=operands, outputs=[out], device="cpu")
    tape.backward(grads={out: wp.ones(len(rows), dtype=float, device="cpu")})
    values = out.numpy()
    gradients = np.column_stack([tape.gradients[item].numpy() for item in operands])
    expected = [reference(case) for case in rows]
    with np.errstate(over="ignore", under="ignore", invalid="ignore"):
        expected_values = np.asarray([item[0] for item in expected], dtype=np.float32)
        expected_gradients = np.asarray([item[1] for item in expected], dtype=np.float32)
    RECORDS.append({
        "label": label,
        "cases": rows.tolist(),
        "input_bits": rows.view(np.uint32).tolist(),
        "actual_values": values.tolist(),
        "actual_value_bits": values.view(np.uint32).tolist(),
        "actual_gradients": gradients.tolist(),
        "expected_values": expected_values.tolist(),
        "expected_gradients": expected_gradients.tolist(),
    })
    return rows, values, gradients, expected_values, expected_gradients


def both_orders(cases):
    """Preserve explicit permutation controls in the same frozen case group."""
    return cases + [[b, a, k] for a, b, k in cases]


class Counterexamples(unittest.TestCase):
    """Check exact ties, dominant limits, precision boundaries and autodiff."""

    def assert_reference(self, results, exact=False, gradient_atol=2e-6):
        """Reject NaN contamination and match independent expected classifications."""
        rows, values, gradients, ev, eg = results
        self.assertTrue(np.isfinite(values).all(), "finite inputs produced a nonfinite mean")
        self.assertFalse(np.isnan(gradients).any(), "reverse-mode gradients contain NaN")
        np.testing.assert_array_equal(np.isposinf(gradients), np.isposinf(eg))
        np.testing.assert_array_equal(np.isneginf(gradients), np.isneginf(eg))
        if exact:
            np.testing.assert_array_equal(values, ev)
        else:
            np.testing.assert_allclose(values, ev, rtol=4e-7, atol=0)
        finite = np.isfinite(eg)
        np.testing.assert_allclose(gradients[finite], eg[finite], rtol=3e-5, atol=gradient_atol)
        self.assertTrue(np.all(values >= np.minimum(rows[:, 0], rows[:, 1])))
        self.assertTrue(np.all(values <= np.maximum(rows[:, 0], rows[:, 1])))
        np.testing.assert_allclose(gradients[:, 0] + gradients[:, 1], 1.0, rtol=3e-6, atol=3e-6)

    def test_exact_alpha_zero_means_and_permutations(self):
        """Preserve exactly representable large and cancellation-sensitive means."""
        predecessor = np.nextafter(FMAX, np.float32(0))
        pairs = [
            [FMAX, FMAX], [-FMAX, -FMAX], [FMAX, -FMAX],
            [FMAX, -predecessor], [3e38, -3e38],
            [1, np.nextafter(np.float32(-1), np.float32(0))],
            [16777216, -16777215], [100000000, -99999992],
        ]
        cases = both_orders([[a, b, alpha] for a, b in pairs for alpha in [0.0, -0.0]])
        result = public_results(cases, "exact-alpha-zero-means")
        self.assert_reference(result, exact=True, gradient_atol=0)
        np.testing.assert_array_equal(result[2][:, :2], np.full((len(cases), 2), 0.5, dtype=np.float32))
        half = len(cases) // 2
        np.testing.assert_array_equal(result[1][:half], result[1][half:])

    def test_signed_zero_tie_value_bits_and_gradients(self):
        """Retain the stable tie-selected signed-zero result and half input gradients."""
        cases = [[a, b, k] for a in [0.0, -0.0] for b in [0.0, -0.0]
                 for k in [0.0, -0.0, 1.0, -1.0, FMAX, -FMAX]]
        result = public_results(cases, "signed-zero-ties")
        rows, values, gradients, _, _ = result
        expected_negative = np.signbit(rows[:, 0]) & np.signbit(rows[:, 1])
        np.testing.assert_array_equal(values.view(np.uint32), np.where(expected_negative, 0x80000000, 0).astype(np.uint32))
        np.testing.assert_array_equal(gradients[:, :2], np.full((len(cases), 2), 0.5, dtype=np.float32))
        np.testing.assert_array_equal(gradients[:, 2], np.zeros(len(cases), dtype=np.float32))

    def test_equal_inputs_with_extreme_sharpness(self):
        """Keep equal-input means and input gradients finite at extreme alpha."""
        cases = [[a, a, k] for a in [FMAX, -FMAX, 3e38, -3e38, 1.0, -1.0]
                 for k in [FMAX, -FMAX, 1.0, -1.0, 0.0, -0.0]]
        self.assert_reference(public_results(cases, "equal-input-extreme-sharpness"), exact=True, gradient_atol=0)

    def test_saturated_extreme_values_and_reverse_gradients(self):
        """Reach exact dominant-input limits without contaminating input adjoints."""
        cases = both_orders([[a, b, k] for a, b in [[FMAX, -FMAX], [3e38, -3e38], [2.0, 3.0]]
                             for k in [FMAX, -FMAX, 1.0, -1.0]
                             if abs(float(k) * (float(a) - float(b))) > 800])
        self.assert_reference(public_results(cases, "saturated-extremes"), exact=True, gradient_atol=0)

    def test_extreme_operands_with_small_sharpness(self):
        """Retain finite input gradients when a nonsaturated alpha derivative overflows."""
        cases = both_orders([[a, b, k] for a, b in [[FMAX, -FMAX], [FMAX, 0.0], [FMAX, -0.5 * FMAX]]
                             for k in [NORMAL_MIN, -NORMAL_MIN, 0.0, -0.0]])
        self.assert_reference(public_results(cases, "extreme-operands-small-sharpness"), gradient_atol=0)

    def test_underflowed_relative_weights_keep_alpha_gradient(self):
        """Retain representable alpha derivatives after losing float32-sized weights."""
        cases = both_orders([[1e20, 0.0, 1.1e-18], [1e20, 0.0, -1.1e-18],
                             [1e20, 0.0, 1.0e-18], [1e20, 0.0, -1.0e-18]])
        result = public_results(cases, "underflowed-relative-weight")
        self.assert_reference(result, gradient_atol=0)
        self.assertTrue(np.all(result[2][:, 2] > 0))

    def test_fixed_decimal_reference_grid(self):
        """Match a deterministic ordinary, shifted and near-tie reference grid."""
        cases = both_orders([
            [1000.0, 999.0, 1.0], [-1000.0, -999.0, 1.0],
            [1000.0, 999.0, -1.0], [-1000.0, -999.0, -1.0],
            [100000.0, 100000.03125, 32.0], [100000.0, 100000.03125, -32.0],
            [1.0, np.nextafter(np.float32(1), np.float32(2)), FMAX],
            [1.0, np.nextafter(np.float32(1), np.float32(0)), -FMAX],
            [2.0, -3.0, 0.01], [2.0, -3.0, -0.01],
        ])
        rng = np.random.default_rng(20261010)
        cases += rng.uniform([-3, -3, -5], [3, 3, 5], size=(48, 3)).astype(np.float32).tolist()
        self.assert_reference(public_results(cases, "fixed-decimal-reference-grid"))

    def test_disclosed_tiny_cancellation_is_observed_without_accuracy_claim(self):
        """Record the existing tiny-value limit while requiring its alpha derivative."""
        result = public_results(both_orders([[1e-20, -1e-20, 1.0]]), "disclosed-tiny-cancellation-limit")
        # Its approximately 1e-40 value is deliberately not a pass/fail criterion.
        # The repair claims retention of the representable derivative instead.
        self.assertTrue(np.isfinite(result[1]).all())
        self.assertTrue(np.isfinite(result[2]).all())
        self.assertTrue(np.all(result[2][:, 2] > 0))
        np.testing.assert_allclose(result[2][:, 2], result[4][:, 2], rtol=3e-5, atol=0)


def safe_json(value):
    """Store explicit nonfinite classifications without invalid JSON numbers."""
    if isinstance(value, float) and not math.isfinite(value):
        return "NaN" if math.isnan(value) else ("+Infinity" if value > 0 else "-Infinity")
    if isinstance(value, list):
        return [safe_json(item) for item in value]
    if isinstance(value, dict):
        return {key: safe_json(item) for key, item in value.items()}
    return value


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    wp.init()
    source = Path(newton.__file__).parent / "_src/math/__init__.py"
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Counterexamples)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {
        "evidence_kind": "NEW independent suite; historical 3 regressions/34 probes unavailable",
        "arm": args.arm,
        "source_path": str(source.resolve()),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "suite_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "warp_version": wp.__version__,
        "numpy_version": np.__version__,
        "device": "cpu",
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "recorded_case_count": sum(len(item["cases"]) for item in RECORDS),
        "outcomes": RECORDS,
        "test_failures": [{"test": str(test), "traceback": tb} for test, tb in result.failures + result.errors],
    }
    Path(args.report).write_text(json.dumps(safe_json(report), indent=2, allow_nan=False) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
